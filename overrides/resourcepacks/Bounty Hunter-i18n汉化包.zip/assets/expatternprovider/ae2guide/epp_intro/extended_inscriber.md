---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: 扩展压印器
    icon: expatternprovider:ex_inscriber
categories:
- extended devices
item_ids:
- expatternprovider:ex_inscriber
---

# 扩展压印器

<Row gap="20">
<BlockImage id="expatternprovider:ex_inscriber" scale="8"></BlockImage>
</Row>

扩展压印器是一种更高级的<ItemLink id="ae2:inscriber" />。

它可以同时运行4个压印任务。

有一个按钮可以改变最大堆叠数量，使其像正常压印器那样工作。

建议在与<ItemLink id="ae2:pattern_provider" />一起使用时将堆叠数量设置为1，以避免某些可能出现的问题。
