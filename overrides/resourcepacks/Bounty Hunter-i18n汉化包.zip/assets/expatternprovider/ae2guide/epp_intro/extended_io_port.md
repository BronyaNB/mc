---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME扩展IO端口
    icon: expatternprovider:ex_io_port
categories:
- extended devices
item_ids:
- expatternprovider:ex_io_port
---

# ME扩展IO端口

<Row gap="20">
<BlockImage id="expatternprovider:ex_io_port" p:powered="true" scale="8"></BlockImage>
</Row>

ME扩展IO端口比普通<ItemLink id="ae2:io_port" />的传输速度快8倍。

与普通的相比，它也有更多的升级插槽。